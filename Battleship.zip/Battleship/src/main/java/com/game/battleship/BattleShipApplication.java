package com.game.battleship;

import com.game.battleship.controller.BatteleShipController;

/**
 * Hello world!
 *
 */
public class BattleShipApplication 
{
    public static void main( String[] args )
    {
        System.out.println( "**** Welcome to Battle Ships game ****" );
        BatteleShipController c = new BatteleShipController();
    }
}
