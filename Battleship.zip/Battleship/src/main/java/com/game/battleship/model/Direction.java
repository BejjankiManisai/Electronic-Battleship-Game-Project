package com.game.battleship.model;

public enum Direction {
	HORIZONTAL,VERTICAL
}
