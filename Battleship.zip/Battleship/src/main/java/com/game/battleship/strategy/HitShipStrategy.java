package com.game.battleship.strategy;

public interface HitShipStrategy {
	public int hitShip();

}
