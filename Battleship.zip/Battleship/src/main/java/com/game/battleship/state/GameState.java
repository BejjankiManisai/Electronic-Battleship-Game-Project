package com.game.battleship.state;

public interface GameState {
	public void newGame();
	public void start();
}
