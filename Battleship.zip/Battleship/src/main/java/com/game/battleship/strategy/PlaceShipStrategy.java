package com.game.battleship.strategy;

import com.game.battleship.model.Ship;

public interface PlaceShipStrategy {
	public Ship placeRandomShip();
}
